interface Quiz {
  Id: number;
  Title: string;
  Description: string;
  Text: string;
}


